import streamlit as st

from snapshot_manager import (
    save_snapshot
)

from compare_snapshots import (
    compare_snapshots
)

st.set_page_config(
    page_title="DynamoDB Validator",
    layout="wide"
)

st.title(
    "AWS DynamoDB Validation Utility"
)

st.markdown("---")

st.header(
    "1. Capture DEV / TEST / MO"
)

if st.button(
    "Capture NONPROD Snapshots"
):

    st.success(
        save_snapshot("DEV")
    )

    st.success(
        save_snapshot("TEST")
    )

    st.success(
        save_snapshot("MO")
    )

st.markdown("---")

st.header(
    "2. Capture PROD"
)

if st.button(
    "Capture PROD Snapshot"
):

    st.success(
        save_snapshot("PROD")
    )

st.markdown("---")

st.header(
    "3. Run Validation"
)

if st.button(
    "Run Comparison"
):

    report_path = (
        compare_snapshots()
    )

    st.success(
        "Validation Completed"
    )

    st.success(
        f"Report Generated : "
        f"{report_path}"
    )
