import boto3
import json
import os

from config import (
    REGION,
    ENVIRONMENTS
)

def create_client():

    return boto3.client(
        "dynamodb",
        region_name=REGION
    )

def extract_structure(data):

    if isinstance(data, dict):

        structure = {}

        for key, value in data.items():

            if key in [
                "S",
                "N",
                "BOOL",
                "NULL",
                "M",
                "L"
            ]:

                if key == "M":

                    structure["M"] = extract_structure(
                        value
                    )

                elif key == "L":

                    if len(value) > 0:

                        structure["L"] = extract_structure(
                            value[0]
                        )

                    else:

                        structure["L"] = []

                else:

                    structure[key] = "DATATYPE"

            else:

                structure[key] = extract_structure(
                    value
                )

        return structure

    return str(type(data))

def save_snapshot(environment):

    client = create_client()

    table_name = ENVIRONMENTS[
        environment
    ]["table"]

    response = client.scan(
        TableName=table_name
    )

    items = response["Items"]

    snapshot_data = {}

    for item in items:

        lookup_code = item[
            "lookupCode"
        ]["S"]

        snapshot_data[
            lookup_code
        ] = extract_structure(item)

    os.makedirs(
        "snapshots",
        exist_ok=True
    )

    file_path = (
        f"snapshots/"
        f"{environment.lower()}_snapshot.json"
    )

    with open(
        file_path,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            snapshot_data,
            file,
            indent=4
        )

    return (
        f"{environment} snapshot saved"
    )
