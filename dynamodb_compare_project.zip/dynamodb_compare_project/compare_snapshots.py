import json
import os

from report_generator import (
    generate_report
)

def load_snapshot(environment):

    file_path = (
        f"snapshots/"
        f"{environment.lower()}_snapshot.json"
    )

    if not os.path.exists(file_path):

        return None

    with open(
        file_path,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)

def compare_snapshots():

    environments = [
        "DEV",
        "TEST",
        "MO",
        "PROD"
    ]

    environment_summary = []

    active_envs = []

    for env in environments:

        data = load_snapshot(env)

        if data:

            status = "AVAILABLE"

            active_envs.append({
                "environment": env,
                "data": data
            })

        else:

            status = "MISSING"

        environment_summary.append({

            "environment": env,
            "status": status
        })

    detailed_results = []

    total_fields = 0
    matched_fields = 0
    different_fields = 0
    missing_fields = 0

    comparison_results = []

    for index in range(
        len(active_envs) - 1
    ):

        source = active_envs[index]

        target = active_envs[index + 1]

        source_name = source[
            "environment"
        ]

        target_name = target[
            "environment"
        ]

        comparison_name = (
            f"{source_name} vs {target_name}"
        )

        source_data = source["data"]
        target_data = target["data"]

        all_keys = sorted(
            set(source_data.keys()).union(
                set(target_data.keys())
            )
        )

        failed = False

        for key in all_keys:

            total_fields += 1

            if key not in source_data:

                failed = True

                missing_fields += 1

                detailed_results.append({

                    "comparison":
                        comparison_name,

                    "lookupCode":
                        key,

                    "status":
                        "MISSING",

                    "details":
                        f"{key} missing "
                        f"in {source_name}"
                })

            elif key not in target_data:

                failed = True

                missing_fields += 1

                detailed_results.append({

                    "comparison":
                        comparison_name,

                    "lookupCode":
                        key,

                    "status":
                        "MISSING",

                    "details":
                        f"{key} missing "
                        f"in {target_name}"
                })

            elif (
                source_data[key]
                ==
                target_data[key]
            ):

                matched_fields += 1

                detailed_results.append({

                    "comparison":
                        comparison_name,

                    "lookupCode":
                        key,

                    "status":
                        "MATCHED",

                    "details":
                        "Structure matched"
                })

            else:

                failed = True

                different_fields += 1

                detailed_results.append({

                    "comparison":
                        comparison_name,

                    "lookupCode":
                        key,

                    "status":
                        "DIFFERENT",

                    "details":
                        (
                            f"{source_name} "
                            f"and "
                            f"{target_name} "
                            f"structure mismatch"
                        )
                })

        comparison_results.append({

            "comparison":
                comparison_name,

            "result":
                "FAILED"
                if failed
                else "PASSED"
        })

    final_summary = {

        "Total Environments":
            len(environments),

        "Active Environments":
            len(active_envs),

        "Total Fields Compared":
            total_fields,

        "Matched Fields":
            matched_fields,

        "Different Fields":
            different_fields,

        "Missing Fields":
            missing_fields
    }

    report_path = generate_report(

        environment_summary,
        comparison_results,
        detailed_results,
        final_summary
    )

    return report_path
