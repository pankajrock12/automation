REGION = "us-east-1"

ENVIRONMENTS = {

    "DEV": {
        "table": "pabio-bill-lookup-table-dev"
    },

    "TEST": {
        "table": "pabio-bill-lookup-table-test"
    },

    "MO": {
        "table": "pabio-bill-lookup-table-mo"
    },

    "PROD": {
        "table": "pabio-bill-lookup-table-prod"
    }
}
