from datetime import datetime
import os

def generate_report(
    environment_summary,
    comparison_results,
    detailed_results,
    final_summary
):

    os.makedirs(
        "reports",
        exist_ok=True
    )

    html = """

    <html>

    <head>

    <style>

    body {
        font-family: Arial;
        margin: 20px;
    }

    h1 {
        color: #2F5597;
    }

    h2 {
        background-color: #d9ead3;
        padding: 10px;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        margin-bottom: 20px;
    }

    th {
        background-color: #4472C4;
        color: white;
        border: 1px solid black;
        padding: 10px;
    }

    td {
        border: 1px solid black;
        padding: 8px;
    }

    .matched {
        background-color: #c6efce;
    }

    .different {
        background-color: #ffc7ce;
    }

    .missing {
        background-color: #ffeb9c;
    }

    </style>

    </head>

    <body>

    <h1>DynamoDB Validation Report</h1>

    """

    html += f"""

    <p>
    Generated Time :
    {datetime.now()}
    </p>

    """

    html += """

    <h2>1. Executive Summary</h2>

    <table>

    """

    for key, value in final_summary.items():

        html += f"""

        <tr>
            <td><b>{key}</b></td>
            <td>{value}</td>
        </tr>

        """

    html += "</table>"

    html += """

    <h2>2. Environment Availability</h2>

    <table>

    <tr>
        <th>Environment</th>
        <th>Status</th>
    </tr>

    """

    for row in environment_summary:

        css_class = (
            "matched"
            if row["status"] == "AVAILABLE"
            else "missing"
        )

        html += f"""

        <tr class="{css_class}">
            <td>{row['environment']}</td>
            <td>{row['status']}</td>
        </tr>

        """

    html += "</table>"

    html += """

    <h2>3. Comparison Results</h2>

    <table>

    <tr>
        <th>Comparison</th>
        <th>lookupCode</th>
        <th>Status</th>
        <th>Issue</th>
    </tr>

    """

    for row in detailed_results:

        status = row["status"]

        if status == "MATCHED":

            css_class = "matched"

        elif status == "DIFFERENT":

            css_class = "different"

        else:

            css_class = "missing"

        html += f"""

        <tr class="{css_class}">
            <td>{row['comparison']}</td>
            <td>{row['lookupCode']}</td>
            <td>{row['status']}</td>
            <td><pre>{row['details']}</pre></td>
        </tr>

        """

    html += """

    </table>

    </body>
    </html>

    """

    report_path = (
        "reports/"
        "final_validation_report.html"
    )

    with open(
        report_path,
        "w",
        encoding="utf-8"
    ) as file:

        file.write(html)

    return report_path
