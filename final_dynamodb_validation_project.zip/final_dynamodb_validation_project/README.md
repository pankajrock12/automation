
# DynamoDB Validation Project

## Run Project

1. Create venv

py -m venv venv

2. Activate

venv\Scripts\activate

3. Install

pip install -r requirements.txt

4. Run

streamlit run main.py
