REGION = "us-east-1"

ENVIRONMENTS = {
    "DEV": "pabio-bill-lookup-table-dev",
    "TEST": "pabio-bill-lookup-table-test",
    "MO": "pabio-bill-lookup-table-mo",
    "PROD": "pabio-bill-lookup-table-prod"
}
