import streamlit as st

st.set_page_config(
    page_title="DynamoDB Validation Tool",
    layout="wide"
)

st.title("DynamoDB Environment Validation Tool")

st.success("Project Setup Successful")
