import json
import os

SNAPSHOT_FOLDER = "snapshots"


def load_snapshot(environment):

    file_path = f"{SNAPSHOT_FOLDER}/{environment.lower()}_snapshot.json"

    if not os.path.exists(file_path):
        return {}

    with open(file_path, "r") as file:
        return json.load(file)


def compare_two_env(base_env, compare_env, base_data, compare_data):

    comparison_result = []

    for table_name in base_data:

        base_table = base_data.get(table_name, {})

        compare_table = compare_data.get(table_name, {})

        all_lookup_codes = set(base_table.keys()) | set(compare_table.keys())

        for lookup_code in all_lookup_codes:

            base_item = base_table.get(lookup_code, {})
            compare_item = compare_table.get(lookup_code, {})

            all_fields = set(base_item.keys()) | set(compare_item.keys())

            matched = 0
            different = 0
            missing = 0

            details = []

            for field in all_fields:

                base_type = base_item.get(field)
                compare_type = compare_item.get(field)

                if base_type and compare_type:

                    if base_type == compare_type:

                        status = "MATCHED"
                        matched += 1

                    else:

                        status = "DATATYPE_MISMATCH"
                        different += 1

                elif base_type and not compare_type:

                    status = "MISSING_IN_COMPARE"
                    missing += 1

                else:

                    status = "MISSING_IN_BASE"
                    missing += 1

                details.append({
                    "field": field,
                    "base_type": base_type,
                    "compare_type": compare_type,
                    "status": status
                })

            comparison_result.append({
                "table": table_name,
                "lookup_code": lookup_code,
                "base_env": base_env,
                "compare_env": compare_env,
                "matched": matched,
                "different": different,
                "missing": missing,
                "details": details
            })

    return comparison_result


def compare_all_environments():

    results = []

    dev = load_snapshot("DEV")
    test = load_snapshot("TEST")
    mo = load_snapshot("MO")
    prod = load_snapshot("PROD")

    if dev and test:
        results.extend(compare_two_env("DEV", "TEST", dev, test))

    if dev and mo:
        results.extend(compare_two_env("DEV", "MO", dev, mo))

    if dev and prod:
        results.extend(compare_two_env("DEV", "PROD", dev, prod))

    return results
