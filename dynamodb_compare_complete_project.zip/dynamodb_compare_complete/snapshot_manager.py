import boto3
import json
import os

from config import (
    REGION,
    TABLES,
    NONPROD_CREDENTIAL_FILE,
    PROD_CREDENTIAL_FILE
)

SNAPSHOT_FOLDER = "snapshots"

os.makedirs(SNAPSHOT_FOLDER, exist_ok=True)


def load_credentials(file_path):

    creds = {}

    with open(file_path, "r") as file:

        for line in file.readlines():

            line = line.strip()

            if "=" in line:

                key, value = line.split("=", 1)

                creds[key.strip()] = value.strip()

    return creds


def create_client(environment):

    if environment == "PROD":
        creds = load_credentials(PROD_CREDENTIAL_FILE)
    else:
        creds = load_credentials(NONPROD_CREDENTIAL_FILE)

    client = boto3.client(
        "dynamodb",
        region_name=REGION,
        aws_access_key_id=creds.get("aws_access_key_id"),
        aws_secret_access_key=creds.get("aws_secret_access_key"),
        aws_session_token=creds.get("aws_session_token")
    )

    return client


def extract_schema(item):

    schema = {}

    for key, value in item.items():

        datatype = list(value.keys())[0]

        schema[key] = datatype

    return schema


def save_snapshot(environment):

    client = create_client(environment)

    tables = TABLES[environment]

    environment_data = {}

    for table_name in tables:

        response = client.scan(
            TableName=table_name
        )

        items = response.get("Items", [])

        table_result = {}

        for item in items:

            lookup_code = item.get("lookupCode", {}).get("S", "UNKNOWN")

            table_result[lookup_code] = extract_schema(item)

        environment_data[table_name] = table_result

    output_file = f"{SNAPSHOT_FOLDER}/{environment.lower()}_snapshot.json"

    with open(output_file, "w") as file:
        json.dump(environment_data, file, indent=4)

    return output_file
