import streamlit as st
import webbrowser
import os

from snapshot_manager import save_snapshot
from compare_snapshots import compare_all_environments
from report_generator import generate_html_report

st.set_page_config(
    page_title="DynamoDB Validation Tool",
    layout="wide"
)

st.title("DynamoDB Environment Validation Tool")

st.markdown("---")

st.header("1. Capture DEV / TEST / MO")

if st.button("Capture NONPROD Snapshots"):

    try:

        save_snapshot("DEV")
        save_snapshot("TEST")
        save_snapshot("MO")

        st.success(
            "NONPROD snapshots captured successfully"
        )

    except Exception as e:
        st.error(str(e))

st.markdown("---")

st.header("2. Capture PROD")

if st.button("Capture PROD Snapshot"):

    try:

        save_snapshot("PROD")

        st.success(
            "PROD snapshot saved"
        )

    except Exception as e:
        st.error(str(e))

st.markdown("---")

st.header("3. Run Validation")

if st.button("Run Validation"):

    try:

        results = compare_all_environments()

        report_path = generate_html_report(results)

        full_path = os.path.abspath(report_path)

        st.success(
            "Validation completed successfully"
        )

        st.markdown(
            f'''
            <a href="file:///{full_path}" target="_blank">
                Open Validation Report
            </a>
            ''',
            unsafe_allow_html=True
        )

        webbrowser.open(
            f"file:///{full_path}"
        )

    except Exception as e:
        st.error(str(e))
