REGION = "us-east-1"

TABLES = {
    "DEV": [
        "pabio-bill-lookup-table-dev"
    ],

    "TEST": [
        "pabio-bill-lookup-table-test"
    ],

    "MO": [
        "pabio-bill-lookup-table-mo"
    ],

    "PROD": [
        "pabio-bill-lookup-table-prod"
    ]
}

NONPROD_CREDENTIAL_FILE = "credentials/nonprod_credentials"
PROD_CREDENTIAL_FILE = "credentials/prod_credentials"
