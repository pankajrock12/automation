import os

REPORT_FOLDER = "reports"

os.makedirs(REPORT_FOLDER, exist_ok=True)


def generate_html_report(results):

    report_file = (
        f"{REPORT_FOLDER}/final_validation_report.html"
    )

    total_match = 0
    total_diff = 0
    total_missing = 0

    html = '''
    <html>
    <head>

    <style>

    body {
        font-family: Arial;
        padding: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }

    th {
        background-color: black;
        color: white;
        padding: 10px;
        border: 1px solid #ccc;
    }

    td {
        padding: 10px;
        border: 1px solid #ccc;
    }

    .matched {
        background-color: #d4edda;
    }

    .different {
        background-color: #f8d7da;
    }

    .missing {
        background-color: #fff3cd;
    }

    </style>

    </head>

    <body>

    <h1>DynamoDB Environment Validation Report</h1>
    '''

    for result in results:

        total_match += result["matched"]
        total_diff += result["different"]
        total_missing += result["missing"]

    html += f'''

    <h2>Summary</h2>

    <table>

        <tr>
            <th>Total Matched</th>
            <th>Total Different</th>
            <th>Total Missing</th>
        </tr>

        <tr>
            <td class='matched'>{total_match}</td>
            <td class='different'>{total_diff}</td>
            <td class='missing'>{total_missing}</td>
        </tr>

    </table>

    '''

    for result in results:

        html += f'''

        <h2>
            {result['base_env']} vs {result['compare_env']}
        </h2>

        <h3>
            Table : {result['table']}
        </h3>

        <h3>
            LookupCode : {result['lookup_code']}
        </h3>

        <table>

        <tr>
            <th>Field</th>
            <th>Base Datatype</th>
            <th>Compare Datatype</th>
            <th>Status</th>
        </tr>

        '''

        for detail in result["details"]:

            css = "matched"

            if detail["status"] == "DATATYPE_MISMATCH":
                css = "different"

            if "MISSING" in detail["status"]:
                css = "missing"

            html += f'''

            <tr class='{css}'>
                <td>{detail['field']}</td>
                <td>{detail['base_type']}</td>
                <td>{detail['compare_type']}</td>
                <td>{detail['status']}</td>
            </tr>

            '''

        html += "</table>"

    html += "</body></html>"

    with open(report_file, "w", encoding="utf-8") as file:
        file.write(html)

    return report_file
